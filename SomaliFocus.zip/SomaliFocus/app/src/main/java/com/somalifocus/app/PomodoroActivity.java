package com.somalifocus.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Set up and start a Pomodoro: a task, work minutes, break minutes, and rounds. */
public class PomodoroActivity extends Activity {

    private static final int GREEN = Color.parseColor("#0B6E3B");
    private static final int INK = Color.parseColor("#10291B");
    private static final int MUTED = Color.parseColor("#3E6B52");
    private static final int TINT = Color.parseColor("#F1F8F4");
    private static final int BORDER = Color.parseColor("#D6EBDD");

    private static final int[] WORK = {15, 25, 30, 45, 60};
    private static final int[] BREAK = {5, 10, 15, 20};
    private static final int[] ROUNDS = {2, 3, 4, 6};

    private EditText task;
    private int work, brk, rounds;
    private LinearLayout workRow, breakRow, roundRow;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(GREEN);
        SharedPreferences p = prefs();
        work = p.getInt(FocusService.KEY_POMO_WORK, FocusService.DEFAULT_POMO_WORK);
        brk = p.getInt(FocusService.KEY_POMO_BREAK, FocusService.DEFAULT_POMO_BREAK);
        rounds = p.getInt(FocusService.KEY_POMO_ROUNDS, FocusService.DEFAULT_POMO_ROUNDS);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.WHITE);
        page.setPadding(dp(20), dp(28), dp(20), dp(28));

        page.addView(title("Pomodoro"));
        page.addView(sub("Work with the phone locked, then it opens for your break. "
                + "Repeats for the number of rounds you choose."));

        page.addView(sectionLabel("Your task"));
        task = new EditText(this);
        task.setHint("e.g. Read chapter 4");
        task.setText(p.getString(FocusService.KEY_POMO_TASK, ""));
        task.setTextSize(16);
        task.setTextColor(INK);
        task.setHintTextColor(Color.parseColor("#9BB6A6"));
        task.setSingleLine(true);
        task.setBackground(rounded(TINT, 14, BORDER));
        task.setPadding(dp(14), dp(14), dp(14), dp(14));
        page.addView(task, wrapMargins(0, 0, 0, 4));

        page.addView(sectionLabel("Work (phone locked)"));
        workRow = chipRow(WORK, work, "min", v -> { work = (int) v; paint(); });
        page.addView(workRow);

        page.addView(sectionLabel("Break (phone open)"));
        breakRow = chipRow(BREAK, brk, "min", v -> { brk = (int) v; paint(); });
        page.addView(breakRow);

        page.addView(sectionLabel("Rounds"));
        roundRow = chipRow(ROUNDS, rounds, "", v -> { rounds = (int) v; paint(); });
        page.addView(roundRow);

        TextView summary = text("", 15, MUTED, false);
        summary.setId(0x5151);
        summary.setPadding(0, dp(18), 0, 0);
        page.addView(summary);

        Button start = bigButton("Start Pomodoro");
        start.setOnClickListener(v -> start());
        page.addView(start, wrapHeightMargins(dp(58), 0, dp(16), 0, 0));

        TextView note = text("The phone locks during each work round, so set it down and focus. "
                + "Emergency calls still work.", 13, MUTED, false);
        note.setPadding(0, dp(14), 0, 0);
        note.setLineSpacing(0, 1.2f);
        page.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.WHITE);
        scroll.addView(page);
        setContentView(scroll);
        paint();
    }

    private SharedPreferences prefs() { return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE); }

    private void paint() {
        repaintRow(workRow, WORK, work);
        repaintRow(breakRow, BREAK, brk);
        repaintRow(roundRow, ROUNDS, rounds);
        TextView s = findViewById(0x5151);
        if (s != null) {
            long total = (long) rounds * work + (long) (rounds - 1) * brk;
            s.setText(rounds + " × " + work + " min work, " + brk + " min breaks  ·  about "
                    + FocusService.fmt(total * 60_000L) + " in total");
        }
    }

    private interface Pick { void on(int value); }

    private LinearLayout chipRow(int[] values, int selected, String unit, Pick pick) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int k = 0; k < values.length; k++) {
            final int val = values[k];
            Button chip = new Button(this);
            chip.setText(unit.isEmpty() ? String.valueOf(val) : val + unit);
            chip.setAllCaps(false);
            chip.setTextSize(15);
            chip.setStateListAnimator(null);
            chip.setPadding(0, 0, 0, 0);
            chip.setOnClickListener(v -> pick.on(val));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
            lp.setMargins(k == 0 ? 0 : dp(4), 0, k == values.length - 1 ? 0 : dp(4), 0);
            row.addView(chip, lp);
        }
        return row;
    }

    private void repaintRow(LinearLayout row, int[] values, int selected) {
        for (int k = 0; k < values.length; k++) {
            Button chip = (Button) row.getChildAt(k);
            boolean sel = values[k] == selected;
            chip.setTextColor(sel ? Color.WHITE : INK);
            chip.setTypeface(sel ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            chip.setBackground(sel ? rounded(GREEN, 12, GREEN)
                    : rounded(Color.WHITE, 12, Color.parseColor("#CFE6D7")));
        }
    }

    private void start() {
        prefs().edit()
                .putString(FocusService.KEY_POMO_TASK, task.getText().toString().trim())
                .putInt(FocusService.KEY_POMO_WORK, work)
                .putInt(FocusService.KEY_POMO_BREAK, brk)
                .putInt(FocusService.KEY_POMO_ROUNDS, rounds)
                .apply();
        if (!MainActivity.isAdmin(this)) {
            Toast.makeText(this, "Allow screen lock first (step 1 on the home screen).", Toast.LENGTH_LONG).show();
            return;
        }
        startForegroundService(new Intent(this, FocusService.class).setAction(FocusService.ACTION_POMO_START));
        Toast.makeText(this, "Pomodoro started. Phone will lock now.", Toast.LENGTH_LONG).show();
        finish();
    }

    // ---- view helpers ----

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView title(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(28); t.setTextColor(INK); t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView sub(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(15); t.setTextColor(MUTED); t.setLineSpacing(0, 1.2f);
        t.setPadding(0, dp(6), 0, dp(4));
        return t;
    }

    private TextView sectionLabel(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(16); t.setTextColor(INK); t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(18), 0, dp(10));
        return t;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button bigButton(String s) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextSize(17); b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setTextColor(Color.WHITE);
        b.setBackground(rounded(GREEN, 16, GREEN));
        return b;
    }

    private LinearLayout.LayoutParams wrapMargins(int l, int t, int r, int bm) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(l), dp(t), dp(r), dp(bm));
        return lp;
    }

    private LinearLayout.LayoutParams wrapHeightMargins(int h, int l, int t, int r, int bm) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, h);
        lp.setMargins(dp(l), dp(t), dp(r), dp(bm));
        return lp;
    }

    private GradientDrawable rounded(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1.5f), stroke);
        return g;
    }
}
