package com.somalifocus.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Turns auto break back on after the phone restarts. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) return;
        if (!c.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .getBoolean(FocusService.KEY_AUTO, false)) return;
        try {
            c.startForegroundService(new Intent(c, FocusService.class).setAction(FocusService.ACTION_WATCH));
        } catch (Exception ignored) {}
    }
}
