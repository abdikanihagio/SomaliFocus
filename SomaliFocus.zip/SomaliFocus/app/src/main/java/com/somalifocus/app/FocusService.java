package com.somalifocus.app;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.database.Cursor;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.DocumentsContract;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * One service does everything:
 *  - counts screen time (phone unlocked and screen on)
 *  - starts an automatic 5-minute break after the chosen number of minutes
 *  - during a break: plays Somali music and re-locks the phone if unlocked
 */
public class FocusService extends Service {

    // Actions
    static final String ACTION_START = "start";          // manual break (START button)
    static final String ACTION_WATCH = "watch";          // turn auto break on
    static final String ACTION_UNWATCH = "unwatch";      // turn auto break off
    static final String ACTION_TOGGLE = "toggle";
    static final String ACTION_NEXT = "next";
    static final String ACTION_STOP_MUSIC = "stop_music";

    // Saved settings / counters
    static final String KEY_AUTO = "auto";
    static final String KEY_LIMIT_MIN = "limit_min";
    static final String KEY_DAY = "day";
    static final String KEY_TODAY_MS = "today_ms";
    static final String KEY_SESSION_MS = "session_ms";
    static final String KEY_BREAKS_TODAY = "breaks_today";
    static final int DEFAULT_LIMIT_MIN = 60;

    private static final long LOCK_MS = 5 * 60 * 1000L;
    private static final long TICK_MS = 15 * 1000L;
    private static final long RESET_AFTER_OFF_MS = 5 * 60 * 1000L;
    private static final String CHANNEL = "focus";
    private static final int NOTIF_ID = 7;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private MediaSession session;
    private List<Uri> songs = new ArrayList<>();
    private List<String> names = new ArrayList<>();
    private int index = 0;
    private int failures = 0;

    private boolean locked = false;
    private long lockEnd = 0;
    private boolean watching = false;
    private long lastTick = 0;
    private long screenOffAt = 0;

    // ---------- Screen events ----------

    private final BroadcastReceiver screenWatcher = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (Intent.ACTION_USER_PRESENT.equals(a)) {
                if (locked && System.currentTimeMillis() < lockEnd) {
                    lockNow(); // unlocked during the break -> lock again
                    return;
                }
                // Phone was locked 5+ minutes on its own: that counts as a break.
                if (screenOffAt > 0 && SystemClock.elapsedRealtime() - screenOffAt >= RESET_AFTER_OFF_MS) {
                    prefs().edit().putLong(KEY_SESSION_MS, 0).apply();
                }
                screenOffAt = 0;
                lastTick = SystemClock.elapsedRealtime();
            } else if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                if (screenOffAt == 0) screenOffAt = SystemClock.elapsedRealtime();
            }
        }
    };

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.elapsedRealtime();
            long dt = lastTick == 0 ? 0 : Math.min(now - lastTick, TICK_MS * 2);
            lastTick = now;
            if (!locked && inUse()) {
                addUsage(dt);
                if (watching && prefs().getLong(KEY_SESSION_MS, 0) >= limitMs()) {
                    prefs().edit().putLong(KEY_SESSION_MS, 0)
                            .putInt(KEY_BREAKS_TODAY, prefs().getInt(KEY_BREAKS_TODAY, 0) + 1).apply();
                    startBreak();
                    return; // startBreak reschedules the tick
                }
            }
            updateNotification();
            handler.postDelayed(this, TICK_MS);
        }
    };

    private final Runnable endLock = () -> {
        locked = false;
        lastTick = SystemClock.elapsedRealtime();
        if (player == null && !watching) stopEverything();
        else updateNotification();
    };

    // ---------- Lifecycle ----------

    @Override
    public void onCreate() {
        super.onCreate();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_USER_PRESENT);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenWatcher, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(screenWatcher, f);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        watching = prefs().getBoolean(KEY_AUTO, false);
        startInForeground(); // Android requires this right away

        if (ACTION_START.equals(action)) {
            startBreak();
        } else if (ACTION_WATCH.equals(action)) {
            watching = true;
            ensureTicking();
        } else if (ACTION_UNWATCH.equals(action)) {
            watching = false;
            if (!locked && player == null) { stopEverything(); return START_NOT_STICKY; }
        } else if (ACTION_TOGGLE.equals(action)) {
            togglePlay();
        } else if (ACTION_NEXT.equals(action)) {
            if (player != null) playIndex(index + 1);
        } else if (ACTION_STOP_MUSIC.equals(action)) {
            releasePlayer();
            if (!locked && !watching) { stopEverything(); return START_NOT_STICKY; }
        } else if (watching) {
            ensureTicking(); // restarted by the system or after reboot
        } else if (!locked && player == null) {
            stopEverything();
            return START_NOT_STICKY;
        }
        updateNotification();
        return watching ? START_STICKY : START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try { unregisterReceiver(screenWatcher); } catch (Exception ignored) {}
        releasePlayer();
        if (session != null) session.release();
        super.onDestroy();
    }

    // ---------- Screen time ----------

    private SharedPreferences prefs() {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
    }

    private long limitMs() {
        return prefs().getInt(KEY_LIMIT_MIN, DEFAULT_LIMIT_MIN) * 60_000L;
    }

    private boolean inUse() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        return pm.isInteractive() && !km.isKeyguardLocked();
    }

    /** Rolls counters over at midnight. Called before reading or adding. */
    static void checkNewDay(SharedPreferences p) {
        String today = LocalDate.now().toString();
        if (!today.equals(p.getString(KEY_DAY, ""))) {
            p.edit().putString(KEY_DAY, today).putLong(KEY_TODAY_MS, 0)
                    .putInt(KEY_BREAKS_TODAY, 0).apply();
        }
    }

    private void addUsage(long dt) {
        if (dt <= 0) return;
        SharedPreferences p = prefs();
        checkNewDay(p);
        p.edit().putLong(KEY_TODAY_MS, p.getLong(KEY_TODAY_MS, 0) + dt)
                .putLong(KEY_SESSION_MS, p.getLong(KEY_SESSION_MS, 0) + dt).apply();
    }

    static String fmt(long ms) {
        long m = ms / 60_000L;
        return m >= 60 ? (m / 60) + "h " + (m % 60) + "m" : m + " min";
    }

    private void ensureTicking() {
        handler.removeCallbacks(tick);
        lastTick = SystemClock.elapsedRealtime();
        handler.postDelayed(tick, TICK_MS);
    }

    // ---------- Break ----------

    private void startBreak() {
        String folder = prefs().getString(MainActivity.KEY_FOLDER, null);
        songs = new ArrayList<>();
        names = new ArrayList<>();
        if (folder != null) {
            songs = listSongs(this, Uri.parse(folder));
            Collections.shuffle(songs);
            for (Uri u : songs) names.add(displayName(u));
        }
        prefs().edit().putLong(KEY_SESSION_MS, 0).apply();

        locked = true;
        lockEnd = System.currentTimeMillis() + LOCK_MS;
        handler.removeCallbacks(endLock);
        handler.postDelayed(endLock, LOCK_MS);
        ensureTicking();

        failures = 0;
        if (!songs.isEmpty()) playIndex(0);
        startInForeground();
        // Give the music a moment to start, then lock.
        handler.postDelayed(this::lockNow, 1200);
    }

    private void lockNow() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        if (dpm.isAdminActive(MainActivity.admin(this))) dpm.lockNow();
    }

    // ---------- Music ----------

    private void playIndex(int i) {
        if (songs.isEmpty()) return;
        index = ((i % songs.size()) + songs.size()) % songs.size();
        releasePlayer();
        MediaPlayer mp = new MediaPlayer();
        try {
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            mp.setDataSource(this, songs.get(index));
            mp.setOnCompletionListener(p -> { failures = 0; playIndex(index + 1); });
            mp.setOnErrorListener((p, w, e) -> {
                if (++failures >= songs.size()) handler.post(this::giveUpMusic);
                else handler.post(() -> playIndex(index + 1));
                return true;
            });
            mp.prepare();
            mp.start();
            player = mp;
        } catch (Exception e) {
            mp.release();
            if (++failures < songs.size()) handler.post(() -> playIndex(index + 1));
            else handler.post(this::giveUpMusic);
            return;
        }
        ensureSession();
        updateNotification();
    }

    private void giveUpMusic() {
        releasePlayer();
        if (!locked && !watching) stopEverything(); else updateNotification();
    }

    private void togglePlay() {
        if (player == null) { if (!songs.isEmpty()) playIndex(index); return; }
        if (player.isPlaying()) player.pause(); else player.start();
        updateNotification();
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
    }

    private void ensureSession() {
        if (session != null) return;
        session = new MediaSession(this, "SomaliFocus");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() {
                if (player == null) { if (!songs.isEmpty()) playIndex(index); }
                else if (!player.isPlaying()) { player.start(); updateNotification(); }
            }
            @Override public void onPause() {
                if (player != null && player.isPlaying()) { player.pause(); updateNotification(); }
            }
            @Override public void onSkipToNext() { if (player != null) playIndex(index + 1); }
            @Override public void onStop() {
                startService(new Intent(FocusService.this, FocusService.class).setAction(ACTION_STOP_MUSIC));
            }
        });
        session.setActive(true);
    }

    // ---------- Notification (shows on the lock screen) ----------

    private PendingIntent action(String a, int code) {
        Intent i = new Intent(this, FocusService.class).setAction(a);
        return PendingIntent.getService(this, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Focus session",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }

        SharedPreferences p = prefs();
        checkNewDay(p);
        String todayLine = "Screen time today: " + fmt(p.getLong(KEY_TODAY_MS, 0));
        long left = Math.max(0, limitMs() - p.getLong(KEY_SESSION_MS, 0));

        boolean playing = player != null && player.isPlaying();
        String song = player != null && index < names.size() ? names.get(index) : null;

        String title, text;
        if (locked) {
            title = "Break time – phone locked";
            text = song != null ? song : "Rest your eyes";
        } else if (song != null) {
            title = song;
            text = todayLine;
        } else {
            title = todayLine;
            text = watching ? "Next break in " + fmt(left + 59_999) : "Auto break is off";
        }

        PendingIntent open = PendingIntent.getActivity(this, 9,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(open)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setOngoing(true);

        if (locked) {
            b.setWhen(lockEnd).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true);
        } else {
            b.setShowWhen(false);
        }

        if (player != null) {
            b.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(this, playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play),
                    playing ? "Pause" : "Play", action(ACTION_TOGGLE, 1)).build());
            b.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_next), "Next", action(ACTION_NEXT, 2)).build());
            b.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop music", action(ACTION_STOP_MUSIC, 3)).build());
            Notification.MediaStyle style = new Notification.MediaStyle().setShowActionsInCompactView(0, 2);
            if (session != null) {
                session.setMetadata(new MediaMetadata.Builder()
                        .putString(MediaMetadata.METADATA_KEY_TITLE, song != null ? song : "Somali music")
                        .putString(MediaMetadata.METADATA_KEY_ARTIST, "Somali Focus").build());
                session.setPlaybackState(new PlaybackState.Builder()
                        .setActions(PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_PLAY
                                | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT
                                | PlaybackState.ACTION_STOP)
                        .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                                PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f).build());
                style.setMediaSession(session.getSessionToken());
            }
            b.setStyle(style);
        }
        return b.build();
    }

    private void startInForeground() {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
            if (player != null || locked) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
            startForeground(NOTIF_ID, n, type);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
    }

    private void stopEverything() {
        handler.removeCallbacksAndMessages(null);
        locked = false;
        releasePlayer();
        if (session != null) { session.release(); session = null; }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    // ---------- Finding songs in the chosen folder ----------

    static List<Uri> listSongs(Context c, Uri tree) {
        List<Uri> out = new ArrayList<>();
        collect(c, tree, DocumentsContract.getTreeDocumentId(tree), out, 0);
        return out;
    }

    private static void collect(Context c, Uri tree, String docId, List<Uri> out, int depth) {
        if (depth > 3) return;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        String[] cols = {DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_MIME_TYPE};
        try (Cursor cur = c.getContentResolver().query(children, cols, null, null, null)) {
            if (cur == null) return;
            while (cur.moveToNext()) {
                String id = cur.getString(0);
                String mime = cur.getString(1);
                if (mime == null) continue;
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    collect(c, tree, id, out, depth + 1);
                } else if (mime.startsWith("audio/") || mime.startsWith("video/")) {
                    out.add(DocumentsContract.buildDocumentUriUsingTree(tree, id));
                }
            }
        } catch (Exception ignored) {}
    }

    private String displayName(Uri u) {
        try (Cursor cur = getContentResolver().query(u,
                new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                String n = cur.getString(0);
                int dot = n.lastIndexOf('.');
                return dot > 0 ? n.substring(0, dot) : n;
            }
        } catch (Exception ignored) {}
        return "Somali music";
    }
}
