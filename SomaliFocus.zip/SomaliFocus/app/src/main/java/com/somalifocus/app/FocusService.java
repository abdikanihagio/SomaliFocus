package com.somalifocus.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.database.Cursor;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.DocumentsContract;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FocusService extends Service {

    static final String ACTION_START = "start";
    static final String ACTION_TOGGLE = "toggle";
    static final String ACTION_NEXT = "next";
    static final String ACTION_STOP_MUSIC = "stop_music";

    private static final long LOCK_MS = 5 * 60 * 1000L;
    private static final String CHANNEL = "focus";
    private static final int NOTIF_ID = 7;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private MediaSession session;
    private List<Uri> songs = new ArrayList<>();
    private List<String> names = new ArrayList<>();
    private int index = 0;
    private boolean locked = false;
    private long lockEnd = 0;
    private boolean receiverOn = false;
    private int failures = 0;

    /** Re-locks the phone if someone unlocks it during the 5 minutes. */
    private final BroadcastReceiver unlockWatcher = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (locked && System.currentTimeMillis() < lockEnd) lockNow();
        }
    };

    private final Runnable endLock = () -> {
        locked = false;
        stopWatching();
        if (player == null) stopEverything();
        else updateNotification();
    };

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        // Always enter foreground right away (Android requires it).
        startInForeground();

        if (ACTION_START.equals(action)) {
            startSession();
        } else if (ACTION_TOGGLE.equals(action)) {
            togglePlay();
        } else if (ACTION_NEXT.equals(action)) {
            if (player != null) playIndex(index + 1);
        } else if (ACTION_STOP_MUSIC.equals(action)) {
            releasePlayer();
            if (!locked) stopEverything();
            else updateNotification();
        } else if (player == null && !locked) {
            stopEverything();
        }
        return START_NOT_STICKY;
    }

    // ---------- Session ----------

    private void startSession() {
        String folder = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getString(MainActivity.KEY_FOLDER, null);
        if (folder == null) { stopEverything(); return; }

        List<Uri> found = listSongs(this, Uri.parse(folder));
        Collections.shuffle(found);
        songs = found;
        names = new ArrayList<>();
        for (Uri u : songs) names.add(displayName(u));

        locked = true;
        lockEnd = System.currentTimeMillis() + LOCK_MS;
        startWatching();
        handler.removeCallbacks(endLock);
        handler.postDelayed(endLock, LOCK_MS);

        if (!songs.isEmpty()) playIndex(0);
        updateNotification();
        // Give the music a moment to start, then lock.
        handler.postDelayed(this::lockNow, 1200);
    }

    private void lockNow() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        if (dpm.isAdminActive(MainActivity.admin(this))) dpm.lockNow();
    }

    private void startWatching() {
        if (receiverOn) return;
        IntentFilter f = new IntentFilter(Intent.ACTION_USER_PRESENT);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(unlockWatcher, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(unlockWatcher, f);
        receiverOn = true;
    }

    private void stopWatching() {
        if (!receiverOn) return;
        try { unregisterReceiver(unlockWatcher); } catch (Exception ignored) {}
        receiverOn = false;
    }

    // ---------- Music ----------

    private void playIndex(int i) {
        if (songs.isEmpty()) return;
        index = ((i % songs.size()) + songs.size()) % songs.size();
        releasePlayer();
        MediaPlayer mp = new MediaPlayer();
        try {
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            mp.setDataSource(this, songs.get(index));
            mp.setOnCompletionListener(p -> { failures = 0; playIndex(index + 1); });
            mp.setOnErrorListener((p, w, e) -> {
                if (++failures >= songs.size()) { handler.post(this::giveUpMusic); }
                else handler.post(() -> playIndex(index + 1));
                return true;
            });
            mp.prepare();
            mp.start();
            player = mp;
        } catch (Exception e) {
            mp.release();
            if (songs.size() > 1) handler.post(() -> {
                songs.remove(index); names.remove(index); playIndex(index);
            });
            return;
        }
        ensureSession();
        updateNotification();
    }

    private void giveUpMusic() {
        releasePlayer();
        if (!locked) stopEverything(); else updateNotification();
    }

    private void togglePlay() {
        if (player == null) { playIndex(index); return; }
        if (player.isPlaying()) player.pause(); else player.start();
        updateNotification();
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
    }

    private void ensureSession() {
        if (session != null) return;
        session = new MediaSession(this, "SomaliFocus");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() {
                if (player == null) playIndex(index);
                else if (!player.isPlaying()) { player.start(); updateNotification(); }
            }
            @Override public void onPause() {
                if (player != null && player.isPlaying()) { player.pause(); updateNotification(); }
            }
            @Override public void onSkipToNext() { playIndex(index + 1); }
            @Override public void onStop() {
                startService(new Intent(FocusService.this, FocusService.class).setAction(ACTION_STOP_MUSIC));
            }
        });
        session.setActive(true);
    }

    // ---------- Notification (shows on the lock screen) ----------

    private PendingIntent action(String a, int code) {
        Intent i = new Intent(this, FocusService.class).setAction(a);
        return PendingIntent.getService(this, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Focus session",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }

        boolean playing = player != null && player.isPlaying();
        String song = player != null && index < names.size() ? names.get(index) : "Music stopped";

        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle(locked ? "Phone locked – take a break" : "Somali Focus")
                .setContentText(song)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true);

        if (locked) {
            b.setWhen(lockEnd).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true);
        }

        if (player != null) {
            b.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(this, playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play),
                    playing ? "Pause" : "Play", action(ACTION_TOGGLE, 1)).build());
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_next), "Next", action(ACTION_NEXT, 2)).build());
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop music", action(ACTION_STOP_MUSIC, 3)).build());
            Notification.MediaStyle style = new Notification.MediaStyle().setShowActionsInCompactView(0, 2);
            if (session != null) {
                session.setMetadata(new MediaMetadata.Builder()
                        .putString(MediaMetadata.METADATA_KEY_TITLE, song)
                        .putString(MediaMetadata.METADATA_KEY_ARTIST, "Somali Focus").build());
                session.setPlaybackState(new PlaybackState.Builder()
                        .setActions(PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_PLAY
                                | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT
                                | PlaybackState.ACTION_STOP)
                        .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                                PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f).build());
                style.setMediaSession(session.getSessionToken());
            }
            b.setStyle(style);
        }
        return b.build();
    }

    private void startInForeground() {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
    }

    private void stopEverything() {
        handler.removeCallbacksAndMessages(null);
        locked = false;
        stopWatching();
        releasePlayer();
        if (session != null) { session.release(); session = null; }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopWatching();
        releasePlayer();
        if (session != null) session.release();
        super.onDestroy();
    }

    // ---------- Finding songs in the chosen folder ----------

    static List<Uri> listSongs(Context c, Uri tree) {
        List<Uri> out = new ArrayList<>();
        collect(c, tree, DocumentsContract.getTreeDocumentId(tree), out, 0);
        return out;
    }

    private static void collect(Context c, Uri tree, String docId, List<Uri> out, int depth) {
        if (depth > 3) return;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        String[] cols = {DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_MIME_TYPE};
        try (Cursor cur = c.getContentResolver().query(children, cols, null, null, null)) {
            if (cur == null) return;
            while (cur.moveToNext()) {
                String id = cur.getString(0);
                String mime = cur.getString(1);
                if (mime == null) continue;
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    collect(c, tree, id, out, depth + 1);
                } else if (mime.startsWith("audio/") || mime.startsWith("video/")) {
                    out.add(DocumentsContract.buildDocumentUriUsingTree(tree, id));
                }
            }
        } catch (Exception ignored) {}
    }

    private String displayName(Uri u) {
        try (Cursor cur = getContentResolver().query(u,
                new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                String n = cur.getString(0);
                int dot = n.lastIndexOf('.');
                return dot > 0 ? n.substring(0, dot) : n;
            }
        } catch (Exception ignored) {}
        return "Somali music";
    }
}
