package com.somalifocus.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Pick which apps Diirad watches, then type the words / links / numbers to block in them. */
public class BlocklistActivity extends Activity {

    private static final int GREEN = Color.parseColor("#0B6E3B");
    private static final int INK = Color.parseColor("#10291B");
    private static final int MUTED = Color.parseColor("#3E6B52");
    private static final int TINT = Color.parseColor("#F1F8F4");
    private static final int BORDER = Color.parseColor("#D6EBDD");

    private EditText words;
    private final List<String> chosen = new ArrayList<>();
    private LinearLayout appList;

    private static class AppRow {
        String label, pkg; Drawable icon;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(GREEN);

        SharedPreferences p = prefs();
        Collections.addAll(chosen, split(p.getString(BlockerService.KEY_APPS, "")));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.WHITE);
        page.setPadding(dp(20), dp(28), dp(20), dp(28));

        page.addView(title("Block searches"));
        page.addView(sub("Pick the apps Diirad should watch, then type what to block. "
                + "If any of it appears in a chosen app, your phone locks for 5 minutes. "
                + "Everything stays on your phone."));

        page.addView(sectionLabel("1. Choose apps to watch"));
        appList = new LinearLayout(this);
        appList.setOrientation(LinearLayout.VERTICAL);
        appList.setBackground(rounded(Color.WHITE, 16, BORDER));
        page.addView(appList);
        TextView loading = text("Loading your apps…", 15, MUTED, false);
        loading.setPadding(dp(14), dp(16), dp(14), dp(16));
        appList.addView(loading);

        page.addView(sectionLabel("2. Words, links or numbers to block"));
        words = new EditText(this);
        words.setHint("porn\nbet\n@somechannel\nt.me/somechannel\n+252 61 1234567");
        words.setText(p.getString(BlockerService.KEY_WORDS, ""));
        words.setTextSize(16);
        words.setTextColor(INK);
        words.setHintTextColor(Color.parseColor("#9BB6A6"));
        words.setGravity(Gravity.TOP | Gravity.START);
        words.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        words.setMinLines(4);
        words.setBackground(rounded(TINT, 14, BORDER));
        words.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wlp.setMargins(0, 0, 0, dp(8));
        page.addView(words, wlp);
        page.addView(text("One per line. Case does not matter.", 13, MUTED, false));

        Button save = bigButton("Save");
        save.setOnClickListener(v -> save());
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        slp.setMargins(0, dp(18), 0, 0);
        page.addView(save, slp);

        TextView access = text("Turn on monitoring in Settings ▸", 16, GREEN, true);
        access.setPadding(0, dp(22), 0, dp(4));
        access.setOnClickListener(v -> openAccessibility());
        page.addView(access);
        page.addView(text("Diirad needs Accessibility access to watch screen text. "
                + "Tap to open the list, find Diirad, and turn it on.", 13, MUTED, false));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.WHITE);
        scroll.addView(page);
        setContentView(scroll);

        loadApps();
    }

    private void loadApps() {
        // Reading every installed app and its icon is slow, so do it off the main
        // thread and then fill the list, to avoid freezing the screen (ANR).
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> infos = pm.queryIntentActivities(launcher, 0);
            List<AppRow> rows = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (ResolveInfo ri : infos) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                AppRow r = new AppRow();
                r.pkg = pkg;
                try { r.label = ri.loadLabel(pm).toString(); } catch (Exception e) { r.label = pkg; }
                try { r.icon = ri.loadIcon(pm); } catch (Exception ignored) {}
                rows.add(r);
            }
            Collections.sort(rows, (a, b) -> a.label.compareToIgnoreCase(b.label));
            runOnUiThread(() -> showApps(rows));
        }).start();
    }

    private void showApps(List<AppRow> rows) {
        if (isFinishing() || isDestroyed()) return;
        appList.removeAllViews();
        if (rows.isEmpty()) {
            TextView none = text("No apps found.", 15, MUTED, false);
            none.setPadding(dp(14), dp(16), dp(14), dp(16));
            appList.addView(none);
            return;
        }
        for (int i = 0; i < rows.size(); i++) {
            appList.addView(appRow(rows.get(i), i < rows.size() - 1));
        }
    }

    private View appRow(AppRow r, boolean divider) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.HORIZONTAL);
        inner.setGravity(Gravity.CENTER_VERTICAL);
        inner.setPadding(dp(14), dp(10), dp(14), dp(10));

        ImageView icon = new ImageView(this);
        if (r.icon != null) icon.setImageDrawable(r.icon);
        inner.addView(icon, new LinearLayout.LayoutParams(dp(36), dp(36)));

        TextView name = text(r.label, 16, INK, false);
        name.setPadding(dp(12), 0, dp(12), 0);
        inner.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        CheckBox cb = new CheckBox(this);
        cb.setChecked(chosen.contains(r.pkg));
        cb.setButtonTintList(android.content.res.ColorStateList.valueOf(GREEN));
        cb.setOnCheckedChangeListener((v, on) -> {
            if (on) { if (!chosen.contains(r.pkg)) chosen.add(r.pkg); }
            else chosen.remove(r.pkg);
        });
        inner.addView(cb);

        inner.setOnClickListener(v -> cb.toggle());
        row.addView(inner);

        if (divider) {
            View line = new View(this);
            line.setBackgroundColor(BORDER);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 1);
            dlp.setMargins(dp(14), 0, 0, 0);
            row.addView(line, dlp);
        }
        return row;
    }

    private SharedPreferences prefs() { return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE); }

    private void save() {
        if (chosen.isEmpty()) { Toast.makeText(this, "Choose at least one app to watch.", Toast.LENGTH_LONG).show(); return; }
        if (words.getText().toString().trim().isEmpty()) { Toast.makeText(this, "Type at least one word to block.", Toast.LENGTH_LONG).show(); return; }
        prefs().edit()
                .putString(BlockerService.KEY_APPS, android.text.TextUtils.join("\n", chosen))
                .putString(BlockerService.KEY_WORDS, words.getText().toString().trim())
                .putBoolean(BlockerService.KEY_BLOCK_ON, true)
                .apply();
        if (!isAccessibilityOn(this)) {
            Toast.makeText(this, "Saved. Now turn Diirad on in Accessibility.", Toast.LENGTH_LONG).show();
            openAccessibility();
        } else {
            Toast.makeText(this, "Saved. Diirad is watching " + chosen.size()
                    + (chosen.size() == 1 ? " app." : " apps."), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void openAccessibility() {
        try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
        catch (Exception e) { Toast.makeText(this, "Open Settings → Accessibility → Diirad", Toast.LENGTH_LONG).show(); }
    }

    static boolean isAccessibilityOn(Context c) {
        String flat = Settings.Secure.getString(c.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return flat != null && flat.contains(c.getPackageName() + "/");
    }

    private static String[] split(String s) {
        if (s == null || s.isEmpty()) return new String[0];
        return s.split("\\n");
    }

    // ---- view helpers ----

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView title(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(28); t.setTextColor(INK); t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView sub(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(15); t.setTextColor(MUTED); t.setLineSpacing(0, 1.2f);
        t.setPadding(0, dp(6), 0, dp(20));
        return t;
    }

    private TextView sectionLabel(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(16); t.setTextColor(INK); t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(18), 0, dp(10));
        return t;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button bigButton(String s) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextSize(17); b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setTextColor(Color.WHITE);
        b.setBackground(rounded(GREEN, 16, GREEN));
        return b;
    }

    private GradientDrawable rounded(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1.5f), stroke);
        return g;
    }
}
