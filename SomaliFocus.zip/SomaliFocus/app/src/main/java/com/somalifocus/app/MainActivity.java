package com.somalifocus.app;

import android.Manifest;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Diirad – green & white home screen, built to match the approved design. */
public class MainActivity extends Activity {

    static final String PREFS = "focus";
    static final String KEY_FOLDER = "folder";
    private static final int REQ_ADMIN = 1;
    private static final int REQ_FOLDER = 2;

    // Palette from the design
    private static final int GREEN = Color.parseColor("#0B6E3B");
    private static final int INK = Color.parseColor("#10291B");
    private static final int MUTED = Color.parseColor("#3E6B52");
    private static final int TINT = Color.parseColor("#F1F8F4");
    private static final int TRACK = Color.parseColor("#E3F2E9");
    private static final int BORDER = Color.parseColor("#D6EBDD");
    private static final int HEADER_SUB = Color.parseColor("#D7F0E1");
    private static final int DISABLED_TEXT = Color.parseColor("#5B7F69");

    private static final int[] LIMITS = {30, 45, 60, 90};

    private TextView headerSub, todayValue, nextBreak, progressText, breaksValue, restedValue, startHint;
    private ProgressBar progress;
    private Button startBtn;
    private Switch autoSwitch;
    private final Button[] limitBtns = new Button[LIMITS.length];
    private LinearLayout statsCard, setupSteps, setupDone, infoNote;
    private TextView musicLine;
    private boolean ignoreSwitch = false;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable statsLoop = new Runnable() {
        @Override public void run() { refreshStats(); ui.postDelayed(this, 5000); }
    };

    // ---------------------------------------------------------------- layout

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(GREEN);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.WHITE);
        page.setClipChildren(false);
        page.setClipToPadding(false);

        page.addView(buildHeader());

        statsCard = buildStatsCard();
        page.addView(statsCard);

        setupSteps = buildSetupSteps();
        page.addView(setupSteps);

        page.addView(buildStartButton());
        page.addView(buildPomodoroCard());
        page.addView(buildAutoCard());
        page.addView(buildBlockerCard());

        setupDone = buildSetupDone();
        page.addView(setupDone);

        infoNote = buildInfoNote();
        page.addView(infoNote);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.WHITE);
        scroll.setClipChildren(false);
        scroll.addView(page);
        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 0);
        }
    }

    private View buildHeader() {
        LinearLayout h = vertical();
        h.setBackgroundColor(GREEN);
        h.setPadding(dp(24), dp(32), dp(24), dp(76));

        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView lock = new ImageView(this);
        lock.setImageResource(R.drawable.ic_lock_line);
        row.addView(lock, new LinearLayout.LayoutParams(dp(28), dp(28)));
        TextView title = text("Diirad", 28, Color.WHITE, true);
        title.setPadding(dp(10), 0, 0, 0);
        row.addView(title);
        h.addView(row);

        headerSub = text("Rest your eyes. Listen to Songs.", 15, HEADER_SUB, false);
        headerSub.setPadding(0, dp(6), 0, 0);
        h.addView(headerSub);
        return h;
    }

    private LinearLayout buildStatsCard() {
        LinearLayout c = vertical();
        c.setBackground(rounded(Color.WHITE, 22, 0, 0));
        c.setElevation(dp(8));
        c.setPadding(dp(22), dp(22), dp(22), dp(22));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(dp(16), -dp(56), dp(16), 0);
        c.setLayoutParams(lp);

        TextView label = text("SCREEN TIME TODAY", 13, MUTED, true);
        label.setLetterSpacing(0.06f);
        c.addView(label);
        todayValue = text("0 min", 44, INK, true);
        c.addView(todayValue);

        LinearLayout row = horizontal();
        row.setPadding(0, dp(12), 0, dp(8));
        nextBreak = text("", 14, MUTED, false);
        row.addView(nextBreak, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        progressText = text("", 14, MUTED, false);
        row.addView(progressText);
        c.addView(row);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        progress.setProgressTintList(ColorStateList.valueOf(GREEN));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(TRACK));
        c.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(10)));

        LinearLayout tiles = horizontal();
        tiles.setPadding(0, dp(16), 0, 0);
        breaksValue = text("0", 22, INK, true);
        restedValue = text("0 min", 22, INK, true);
        tiles.addView(tile(breaksValue, "Breaks today"), weighted(0, dp(5)));
        tiles.addView(tile(restedValue, "Rested today"), weighted(dp(5), 0));
        c.addView(tiles);
        return c;
    }

    private View tile(TextView value, String caption) {
        LinearLayout t = vertical();
        t.setBackground(rounded(TINT, 14, 0, 0));
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        t.addView(value);
        t.addView(text(caption, 13, MUTED, false));
        return t;
    }

    private View buildStartButton() {
        LinearLayout wrap = vertical();
        wrap.setPadding(dp(16), dp(20), dp(16), 0);
        startBtn = new Button(this);
        startBtn.setText("Start 5-minute break");
        startBtn.setAllCaps(false);
        startBtn.setTextSize(18);
        startBtn.setTypeface(Typeface.DEFAULT_BOLD);
        startBtn.setStateListAnimator(null);
        startBtn.setCompoundDrawablePadding(dp(10));
        startBtn.setPadding(dp(20), 0, dp(20), 0);
        startBtn.setOnClickListener(v -> startFocus());
        wrap.addView(startBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)));

        startHint = text("Finish steps 1 and 2 to start.", 14, MUTED, false);
        startHint.setGravity(Gravity.CENTER);
        startHint.setPadding(0, dp(10), 0, 0);
        wrap.addView(startHint);
        return wrap;
    }

    private View buildAutoCard() {
        LinearLayout c = vertical();
        c.setBackground(rounded(Color.WHITE, 20, 2, BORDER));
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(dp(16), dp(20), dp(16), 0);
        c.setLayoutParams(lp);

        LinearLayout top = horizontal();
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout words = vertical();
        words.addView(text("Auto break", 18, INK, true));
        words.addView(text("Lock + music after screen time of:", 14, MUTED, false));
        top.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        autoSwitch = new Switch(this);
        autoSwitch.setContentDescription("Auto break");
        autoSwitch.setThumbTintList(new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}}, new int[]{Color.WHITE, Color.WHITE}));
        autoSwitch.setTrackTintList(new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}}, new int[]{GREEN, Color.parseColor("#B9CFC1")}));
        autoSwitch.setOnCheckedChangeListener((b, on) -> { if (!ignoreSwitch) setAuto(on); });
        top.addView(autoSwitch);
        c.addView(top);

        LinearLayout chips = horizontal();
        chips.setPadding(0, dp(14), 0, 0);
        for (int k = 0; k < LIMITS.length; k++) {
            final int min = LIMITS[k];
            Button b = new Button(this);
            b.setText(min + "m");
            b.setAllCaps(false);
            b.setTextSize(15);
            b.setStateListAnimator(null);
            b.setPadding(0, 0, 0, 0);
            b.setOnClickListener(v -> setLimit(min));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, dp(46), 1f);
            clp.setMargins(k == 0 ? 0 : dp(4), 0, k == LIMITS.length - 1 ? 0 : dp(4), 0);
            chips.addView(b, clp);
            limitBtns[k] = b;
        }
        c.addView(chips);
        return c;
    }

    private View buildPomodoroCard() {
        LinearLayout c = vertical();
        c.setBackground(rounded(Color.WHITE, 20, 2, BORDER));
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(dp(16), dp(20), dp(16), 0);
        c.setLayoutParams(lp);

        LinearLayout words = vertical();
        words.addView(text("Pomodoro", 18, INK, true));
        words.addView(text("Work with the phone locked, then it opens for your break. Repeat.",
                14, MUTED, false));
        c.addView(words);

        Button open = new Button(this);
        open.setText("Set up Pomodoro");
        open.setAllCaps(false);
        open.setTextSize(16);
        open.setTypeface(Typeface.DEFAULT_BOLD);
        open.setStateListAnimator(null);
        open.setTextColor(GREEN);
        open.setBackground(rounded(Color.WHITE, 14, 2, GREEN));
        open.setOnClickListener(v -> startActivity(new Intent(this, PomodoroActivity.class)));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        blp.setMargins(0, dp(14), 0, 0);
        c.addView(open, blp);
        return c;
    }

    private TextView blockerStatus;

    private View buildBlockerCard() {
        LinearLayout c = vertical();
        c.setBackground(rounded(Color.WHITE, 20, 2, BORDER));
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(dp(16), dp(20), dp(16), 0);
        c.setLayoutParams(lp);

        LinearLayout top = horizontal();
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout words = vertical();
        words.addView(text("Block searches", 18, INK, true));
        words.addView(text("Lock when your blocked words, channels or numbers appear in another app.",
                14, MUTED, false));
        top.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        c.addView(top);

        blockerStatus = text("", 14, MUTED, true);
        blockerStatus.setPadding(0, dp(10), 0, 0);
        c.addView(blockerStatus);

        Button edit = new Button(this);
        edit.setText("Edit blocklist");
        edit.setAllCaps(false);
        edit.setTextSize(16);
        edit.setTypeface(Typeface.DEFAULT_BOLD);
        edit.setStateListAnimator(null);
        edit.setTextColor(Color.WHITE);
        edit.setBackground(rounded(GREEN, 14, 0, 0));
        edit.setOnClickListener(v -> startActivity(new Intent(this, BlocklistActivity.class)));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        blp.setMargins(0, dp(14), 0, 0);
        c.addView(edit, blp);
        return c;
    }

    private LinearLayout buildSetupSteps() {
        LinearLayout s = vertical();
        s.setPadding(dp(16), dp(24), dp(16), 0);
        s.addView(stepCard("1", "Allow screen lock",
                "So the app can lock your phone for 5 minutes.", "Allow", true, v -> requestAdmin()));
        View gap = new View(this);
        s.addView(gap, new LinearLayout.LayoutParams(1, dp(12)));
        s.addView(stepCard("2", "Choose your music",
                "Pick your Vidmate download folder.", "Choose folder", false, v -> chooseFolder()));
        return s;
    }

    private View stepCard(String num, String title, String desc, String action, boolean filled,
                          View.OnClickListener l) {
        LinearLayout c = vertical();
        c.setBackground(rounded(Color.WHITE, 20, 2, BORDER));
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setTag(num);

        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge = text(num, 17, GREEN, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(oval(TRACK));
        row.addView(badge, new LinearLayout.LayoutParams(dp(36), dp(36)));
        LinearLayout words = vertical();
        words.setPadding(dp(12), 0, 0, 0);
        words.addView(text(title, 17, INK, true));
        words.addView(text(desc, 14, MUTED, false));
        row.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        c.addView(row);

        Button b = new Button(this);
        b.setText(action);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setTextColor(filled ? Color.WHITE : GREEN);
        b.setBackground(filled ? rounded(GREEN, 14, 0, 0) : rounded(Color.WHITE, 14, 2, GREEN));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        blp.setMargins(0, dp(14), 0, 0);
        c.addView(b, blp);
        return c;
    }

    private LinearLayout buildSetupDone() {
        LinearLayout c = vertical();
        c.setBackground(rounded(TINT, 20, 0, 0));
        c.setPadding(dp(18), dp(6), dp(18), dp(6));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(dp(16), dp(16), dp(16), dp(24));
        c.setLayoutParams(lp);

        c.addView(checkRow("Screen lock allowed", null));
        View line = new View(this);
        line.setBackgroundColor(BORDER);
        c.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        LinearLayout musicRow = checkRow("Music folder chosen", "Change");
        musicLine = (TextView) musicRow.getChildAt(1);
        c.addView(musicRow);
        return c;
    }

    private LinearLayout checkRow(String label, String link) {
        LinearLayout r = horizontal();
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        ImageView check = new ImageView(this);
        check.setImageResource(R.drawable.ic_check);
        check.setBackground(oval(GREEN));
        check.setPadding(dp(6), dp(6), dp(6), dp(6));
        r.addView(check, new LinearLayout.LayoutParams(dp(28), dp(28)));
        TextView t = text(label, 15, INK, false);
        t.setPadding(dp(12), 0, 0, 0);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (link != null) {
            TextView l = text(link, 14, GREEN, true);
            l.setPadding(dp(12), dp(10), 0, dp(10));
            l.setOnClickListener(v -> chooseFolder());
            r.addView(l);
        }
        return r;
    }

    private LinearLayout buildInfoNote() {
        LinearLayout c = horizontal();
        c.setBackground(rounded(TINT, 20, 0, 0));
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(dp(16), dp(24), dp(16), dp(24));
        c.setLayoutParams(lp);
        ImageView info = new ImageView(this);
        info.setImageResource(R.drawable.ic_info);
        c.addView(info, new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView t = text("During a break you can still pause or stop the music from the lock screen, "
                + "and emergency calls always work.", 14, INK, false);
        t.setLineSpacing(0, 1.2f);
        t.setPadding(dp(12), 0, 0, 0);
        c.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return c;
    }

    // ---------------------------------------------------------------- helpers

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weighted(int left, int right) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(left, 0, right, 0);
        return lp;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable rounded(int fill, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp) / 2 + 1, strokeColor);
        return g;
    }

    private GradientDrawable oval(int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        return g;
    }

    private SharedPreferences prefs() { return getSharedPreferences(PREFS, MODE_PRIVATE); }

    static ComponentName admin(Context c) { return new ComponentName(c, AdminReceiver.class); }

    static boolean isAdmin(Context c) {
        DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(DEVICE_POLICY_SERVICE);
        return dpm.isAdminActive(admin(c));
    }

    private String folder() { return prefs().getString(KEY_FOLDER, null); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ---------------------------------------------------------------- state

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        ui.post(statsLoop);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(statsLoop);
    }

    private void refresh() {
        boolean a = isAdmin(this);
        boolean f = folder() != null;
        boolean ready = a && f;

        // First-time vs ready layout (matches the two design screens)
        setupSteps.setVisibility(ready ? View.GONE : View.VISIBLE);
        infoNote.setVisibility(ready ? View.GONE : View.VISIBLE);
        statsCard.setVisibility(ready ? View.VISIBLE : View.GONE);
        setupDone.setVisibility(ready ? View.VISIBLE : View.GONE);
        startHint.setVisibility(ready ? View.GONE : View.VISIBLE);
        headerSub.setText(ready ? "Rest your eyes. Listen to Songs." : "Two quick steps, only once.");
        ((ViewGroup) headerSub.getParent()).setPadding(dp(24), dp(32), dp(24), dp(ready ? 76 : 32));

        // Hide a step once it is done
        setupSteps.getChildAt(0).setVisibility(a ? View.GONE : View.VISIBLE);
        setupSteps.getChildAt(1).setVisibility(a || f ? View.GONE : View.VISIBLE);
        setupSteps.getChildAt(2).setVisibility(f ? View.GONE : View.VISIBLE);

        startBtn.setEnabled(ready);
        startBtn.setTextColor(ready ? Color.WHITE : DISABLED_TEXT);
        startBtn.setBackground(rounded(ready ? GREEN : TRACK, 18, 0, 0));
        Drawable play = getDrawable(R.drawable.ic_play).mutate();
        play.setTint(ready ? Color.WHITE : DISABLED_TEXT);
        play.setBounds(0, 0, dp(22), dp(22));
        startBtn.setCompoundDrawables(play, null, null, null);

        if (f) {
            int n = FocusService.listSongs(this, Uri.parse(folder())).size();
            musicLine.setText("Music: " + n + (n == 1 ? " song" : " songs"));
        }

        ignoreSwitch = true;
        autoSwitch.setChecked(prefs().getBoolean(FocusService.KEY_AUTO, false));
        ignoreSwitch = false;

        int limit = prefs().getInt(FocusService.KEY_LIMIT_MIN, FocusService.DEFAULT_LIMIT_MIN);
        for (int k = 0; k < LIMITS.length; k++) {
            boolean sel = LIMITS[k] == limit;
            limitBtns[k].setTextColor(sel ? Color.WHITE : INK);
            limitBtns[k].setTypeface(sel ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            limitBtns[k].setBackground(sel ? rounded(GREEN, 12, 0, 0) : rounded(Color.WHITE, 12, 2, Color.parseColor("#CFE6D7")));
        }
        boolean blockOn = prefs().getBoolean(BlockerService.KEY_BLOCK_ON, false)
                && BlocklistActivity.isAccessibilityOn(this);
        boolean hasList = !prefs().getString(BlockerService.KEY_WORDS, "").isEmpty()
                && !prefs().getString(BlockerService.KEY_APPS, "").isEmpty();
        blockerStatus.setTextColor(blockOn ? GREEN : MUTED);
        blockerStatus.setText(blockOn ? "● Watching now"
                : hasList ? "Saved, but turn Diirad on in Accessibility" : "Not set up yet");

        refreshStats();
    }

    private void refreshStats() {
        SharedPreferences p = prefs();
        FocusService.checkNewDay(p);
        boolean on = p.getBoolean(FocusService.KEY_AUTO, false);
        int limitMin = p.getInt(FocusService.KEY_LIMIT_MIN, FocusService.DEFAULT_LIMIT_MIN);
        long limit = limitMin * 60_000L;
        long used = Math.min(limit, p.getLong(FocusService.KEY_SESSION_MS, 0));
        int breaks = p.getInt(FocusService.KEY_BREAKS_TODAY, 0);

        todayValue.setText(FocusService.fmt(p.getLong(FocusService.KEY_TODAY_MS, 0)));
        breaksValue.setText(String.valueOf(breaks));
        restedValue.setText(FocusService.fmt(breaks * 5 * 60_000L));
        if (on) {
            nextBreak.setText("Next break in " + FocusService.fmt(limit - used + 59_999));
            progressText.setText((used / 60_000L) + " / " + limitMin + " min");
            progress.setProgress((int) (used * 1000 / limit));
        } else {
            nextBreak.setText("Turn on auto break to count");
            progressText.setText("");
            progress.setProgress(0);
        }
    }

    // ---------------------------------------------------------------- actions

    private void setLimit(int min) {
        prefs().edit().putInt(FocusService.KEY_LIMIT_MIN, min).apply();
        refresh();
    }

    private void setAuto(boolean on) {
        if (on && !isAdmin(this)) {
            toast("Allow screen lock first (step 1)");
            ignoreSwitch = true; autoSwitch.setChecked(false); ignoreSwitch = false;
            return;
        }
        prefs().edit().putBoolean(FocusService.KEY_AUTO, on).apply();
        Intent i = new Intent(this, FocusService.class)
                .setAction(on ? FocusService.ACTION_WATCH : FocusService.ACTION_UNWATCH);
        if (on) startForegroundService(i); else startService(i);
        if (on && folder() == null) toast("Auto break is on. Choose a music folder so music plays too.");
        refresh();
    }

    private void requestAdmin() {
        if (isAdmin(this)) return;
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin(this));
        i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Needed so Diirad can lock your screen for 5 minutes.");
        startActivityForResult(i, REQ_ADMIN);
    }

    private void chooseFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_FOLDER);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FOLDER && res == RESULT_OK && data != null && data.getData() != null) {
            Uri tree = data.getData();
            getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            prefs().edit().putString(KEY_FOLDER, tree.toString()).apply();
            int n = FocusService.listSongs(this, tree).size();
            toast(n + " songs found");
        }
        refresh();
    }

    private void startFocus() {
        if (!isAdmin(this)) { toast("Do step 1 first"); return; }
        if (folder() == null) { toast("Do step 2 first"); return; }
        if (FocusService.listSongs(this, Uri.parse(folder())).isEmpty()) {
            toast("No songs in that folder. Choose your Vidmate download folder.");
            return;
        }
        startForegroundService(new Intent(this, FocusService.class).setAction(FocusService.ACTION_START));
    }
}
