package com.somalifocus.app;

import android.Manifest;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ScrollView;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    static final String PREFS = "focus";
    static final String KEY_FOLDER = "folder";
    private static final int REQ_ADMIN = 1;
    private static final int REQ_FOLDER = 2;

    private TextView status, stats;
    private Button adminBtn, folderBtn, startBtn, autoBtn;
    private final Button[] limitBtns = new Button[4];
    private static final int[] LIMITS = {30, 45, 60, 90};
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable statsLoop = new Runnable() {
        @Override public void run() { refreshStats(); ui.postDelayed(this, 5000); }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(24);
        root.setPadding(pad, dp(56), pad, pad);

        TextView title = new TextView(this);
        title.setText("Somali Focus");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Lock your phone for 5 minutes and listen to Somali music.");
        sub.setTextColor(Color.parseColor("#C9D6E8"));
        sub.setTextSize(16);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(8), 0, dp(32));
        root.addView(sub);

        adminBtn = button("1. Allow screen lock", v -> requestAdmin());
        folderBtn = button("2. Choose music folder", v -> chooseFolder());
        startBtn = button("START  (5 min lock + music)", v -> startFocus());
        startBtn.setBackgroundColor(Color.parseColor("#4189DD"));
        startBtn.setTextSize(18);
        root.addView(adminBtn);
        root.addView(folderBtn);
        root.addView(startBtn);

        status = new TextView(this);
        status.setTextColor(Color.parseColor("#C9D6E8"));
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(12), 0, dp(24));
        root.addView(status);

        // ----- Auto break -----
        TextView autoTitle = new TextView(this);
        autoTitle.setText("Auto break");
        autoTitle.setTextColor(Color.WHITE);
        autoTitle.setTextSize(22);
        autoTitle.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(autoTitle);

        TextView autoSub = new TextView(this);
        autoSub.setText("Lock for 5 minutes with Somali music after this much screen time:");
        autoSub.setTextColor(Color.parseColor("#C9D6E8"));
        autoSub.setGravity(Gravity.CENTER);
        autoSub.setPadding(0, dp(4), 0, dp(4));
        root.addView(autoSub);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int k = 0; k < LIMITS.length; k++) {
            final int min = LIMITS[k];
            Button b = button(min + " min", v -> setLimit(min));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f);
            lp.setMargins(dp(3), dp(6), dp(3), dp(6));
            b.setLayoutParams(lp);
            limitBtns[k] = b;
            row.addView(b);
        }
        root.addView(row);

        autoBtn = button("Turn auto break ON", v -> toggleAuto());
        root.addView(autoBtn);

        stats = new TextView(this);
        stats.setTextColor(Color.WHITE);
        stats.setTextSize(16);
        stats.setGravity(Gravity.CENTER);
        stats.setPadding(0, dp(12), 0, 0);
        root.addView(stats);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#0B2545"));
        scroll.addView(root);
        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 0);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        ui.post(statsLoop);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(statsLoop);
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private void setLimit(int min) {
        prefs().edit().putInt(FocusService.KEY_LIMIT_MIN, min).apply();
        refresh();
        refreshStats();
    }

    private void toggleAuto() {
        boolean on = prefs().getBoolean(FocusService.KEY_AUTO, false);
        if (!on && !isAdmin(this)) { toast("Do step 1 first"); return; }
        prefs().edit().putBoolean(FocusService.KEY_AUTO, !on).apply();
        Intent i = new Intent(this, FocusService.class)
                .setAction(on ? FocusService.ACTION_UNWATCH : FocusService.ACTION_WATCH);
        if (on) startService(i); else startForegroundService(i);
        if (!on && folder() == null) toast("Auto break is on. Choose a music folder so music plays too.");
        refresh();
        refreshStats();
    }

    private void refreshStats() {
        SharedPreferences p = prefs();
        FocusService.checkNewDay(p);
        boolean on = p.getBoolean(FocusService.KEY_AUTO, false);
        long limit = p.getInt(FocusService.KEY_LIMIT_MIN, FocusService.DEFAULT_LIMIT_MIN) * 60_000L;
        long left = Math.max(0, limit - p.getLong(FocusService.KEY_SESSION_MS, 0));
        String txt = "Screen time today: " + FocusService.fmt(p.getLong(FocusService.KEY_TODAY_MS, 0))
                + "\nBreaks today: " + p.getInt(FocusService.KEY_BREAKS_TODAY, 0);
        txt += on ? "\nNext break in: " + FocusService.fmt(left + 59_999)
                  : "\n(Screen time is counted while auto break is on)";
        stats.setText(txt);
    }

    private Button button(String text, android.view.View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#13315C"));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(60));
        lp.setMargins(0, dp(8), 0, dp(8));
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    static ComponentName admin(Context c) {
        return new ComponentName(c, AdminReceiver.class);
    }

    static boolean isAdmin(Context c) {
        DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(DEVICE_POLICY_SERVICE);
        return dpm.isAdminActive(admin(c));
    }

    private String folder() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_FOLDER, null);
    }

    private void refresh() {
        boolean a = isAdmin(this);
        String f = folder();
        adminBtn.setText(a ? "1. Screen lock allowed ✓" : "1. Allow screen lock");
        boolean on = prefs().getBoolean(FocusService.KEY_AUTO, false);
        autoBtn.setText(on ? "Auto break is ON  (tap to turn off)" : "Turn auto break ON");
        autoBtn.setBackgroundColor(Color.parseColor(on ? "#2E8B57" : "#13315C"));
        int limit = prefs().getInt(FocusService.KEY_LIMIT_MIN, FocusService.DEFAULT_LIMIT_MIN);
        for (int k = 0; k < LIMITS.length; k++) {
            limitBtns[k].setBackgroundColor(Color.parseColor(LIMITS[k] == limit ? "#4189DD" : "#13315C"));
        }
        folderBtn.setText(f != null ? "2. Music folder chosen ✓ (tap to change)" : "2. Choose music folder");
        status.setText(a && f != null
                ? "Ready. Tap START.\nDuring the 5 minutes you can pause or stop the music from the lock screen."
                : "Do steps 1 and 2 once. After that, just tap START.");
    }

    private void requestAdmin() {
        if (isAdmin(this)) return;
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin(this));
        i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Needed so the app can lock your screen for 5 minutes.");
        startActivityForResult(i, REQ_ADMIN);
    }

    private void chooseFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_FOLDER);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FOLDER && res == RESULT_OK && data != null && data.getData() != null) {
            Uri tree = data.getData();
            getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_FOLDER, tree.toString()).apply();
            int n = FocusService.listSongs(this, tree).size();
            Toast.makeText(this, n + " songs found", Toast.LENGTH_LONG).show();
        }
        refresh();
    }

    private void startFocus() {
        if (!isAdmin(this)) { toast("Do step 1 first"); return; }
        if (folder() == null) { toast("Do step 2 first"); return; }
        if (FocusService.listSongs(this, Uri.parse(folder())).isEmpty()) {
            toast("No songs in that folder. Choose your Vidmate download folder.");
            return;
        }
        Intent i = new Intent(this, FocusService.class).setAction(FocusService.ACTION_START);
        startForegroundService(i);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
