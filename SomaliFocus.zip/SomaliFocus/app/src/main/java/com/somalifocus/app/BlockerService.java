package com.somalifocus.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Watches the text on screen in the app you are using. When one of YOUR OWN
 * blocked words, Telegram channels, or WhatsApp numbers appears, it starts the
 * same 5-minute Diirad lock. Everything is read and matched on the phone; no
 * text leaves the device, nothing is logged or sent anywhere.
 *
 * This is a self-control tool for the phone's owner, not a way to watch anyone
 * else: it only runs on the phone it is installed and enabled on, by the person
 * who enables it in Settings, and they can turn it off there at any time.
 */
public class BlockerService extends AccessibilityService {

    static final String KEY_BLOCK_ON = "block_on";
    static final String KEY_WORDS = "block_words";     // newline-separated words/links/numbers
    static final String KEY_APPS = "block_apps";       // newline-separated package names to watch
    static final String KEY_LAST_HIT = "block_last_hit";

    // Only look inside apps where self-blocking makes sense; ignore Diirad itself.
    private static final long COOLDOWN_MS = 30 * 1000L;
    private long lastTrigger = 0;
    private final Handler main = new Handler(Looper.getMainLooper());

    private SharedPreferences prefs() {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        SharedPreferences p = prefs();
        if (!p.getBoolean(KEY_BLOCK_ON, false)) return;

        // A break is already running, or we just fired: do nothing.
        if (SystemClock.elapsedRealtime() - lastTrigger < COOLDOWN_MS) return;

        CharSequence pkgCs = event.getPackageName();
        if (pkgCs == null) return;
        String pkg = pkgCs.toString();
        if (pkg.equals(getPackageName()) || pkg.startsWith("com.android.systemui")) return;

        // Only watch the apps the user chose. None chosen = nothing to do.
        String apps = p.getString(KEY_APPS, "");
        if (apps.isEmpty()) return;
        boolean watched = false;
        for (String line : apps.split("\\n")) {
            if (line.trim().equals(pkg)) { watched = true; break; }
        }
        if (!watched) return;

        List<String> terms = terms(p);
        if (terms.isEmpty()) return;

        StringBuilder sb = new StringBuilder();
        CharSequence src = event.getText() != null && !event.getText().isEmpty()
                ? TextUtils.join(" ", event.getText()) : null;
        if (src != null) sb.append(src).append(' ');
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            collectText(root, sb, 0);
            root.recycle();
        }
        if (sb.length() == 0) return;

        String haystack = sb.toString().toLowerCase(Locale.ROOT);
        for (String term : terms) {
            if (!term.isEmpty() && haystack.contains(term)) {
                lastTrigger = SystemClock.elapsedRealtime();
                p.edit().putLong(KEY_LAST_HIT, System.currentTimeMillis()).apply();
                onMatch(term);
                startForegroundService(new Intent(this, FocusService.class)
                        .setAction(FocusService.ACTION_START));
                return;
            }
        }
    }

    /** Visible/felt confirmation that Diirad detected a blocked word, so detection
     *  can be told apart from the lock (which needs Device admin). */
    private void onMatch(String term) {
        main.post(() -> Toast.makeText(this, "Diirad blocked: " + term, Toast.LENGTH_SHORT).show());
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE));
        } catch (Exception ignored) {}
    }

    /** Builds the lowercased list of things to look for from the user's settings. */
    private List<String> terms(SharedPreferences p) {
        List<String> out = new ArrayList<>();
        String blob = p.getString(KEY_WORDS, "");
        if (blob == null) return out;
        for (String raw : blob.split("\\n")) {
            String s = raw.trim().toLowerCase(Locale.ROOT);
            if (s.isEmpty()) continue;
            out.add(s);
            // Also match a simplified form so a channel link or a spaced number still hits.
            String simple = s;
            if (simple.contains("t.me/")) simple = simple.substring(simple.indexOf("t.me/") + 5);
            if (simple.startsWith("@")) simple = simple.substring(1);
            simple = simple.replaceFirst("^https?://", "").replaceAll("[\\s()\\-]", "");
            if (simple.length() >= 3 && !simple.equals(s)) out.add(simple);
        }
        return out;
    }

    private void collectText(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null || depth > 40 || sb.length() > 20000) return;
        CharSequence t = node.getText();
        if (t != null) sb.append(t).append(' ');
        CharSequence d = node.getContentDescription();
        if (d != null) sb.append(d).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectText(child, sb, depth + 1);
                child.recycle();
            }
        }
    }

    @Override
    public void onInterrupt() { }
}
