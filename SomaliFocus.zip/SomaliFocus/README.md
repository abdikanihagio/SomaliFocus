# Diirad

An Android app that locks your phone for 5 minutes and plays Somali music.

- Tap **START**: music starts (songs from your Vidmate download folder, shuffled) and the screen locks.
- If you unlock within 5 minutes, the screen locks again right away.
- On the lock screen you can still **Pause, Next, or Stop music**.
- Emergency calls still work from the lock screen.

## Get the APK
Upload this whole folder to a GitHub repository. GitHub Actions builds it automatically,
and the APK appears under **Releases → latest → SomaliFocus.apk**.

## Uninstall
Settings → Security → Device admin apps → turn off Diirad, then uninstall.
